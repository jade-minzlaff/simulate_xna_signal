README.txt for simulate_xna_signal.py
