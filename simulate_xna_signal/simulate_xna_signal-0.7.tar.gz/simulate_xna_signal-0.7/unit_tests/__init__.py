print("my_package is imported_c")

from . import simulate_xna_signal